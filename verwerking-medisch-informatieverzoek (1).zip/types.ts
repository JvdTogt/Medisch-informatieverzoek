
export interface FileData {
  base64: string;
  mimeType: string;
  name: string;
}

export interface ProcessingState {
  status: 'idle' | 'processing' | 'success' | 'error';
  message?: string;
}

export interface GeneratedContent {
  title: string;
  body: string;
}
